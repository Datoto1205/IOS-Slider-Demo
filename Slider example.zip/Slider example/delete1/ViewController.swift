//
//  ViewController.swift
//  delete1
//
//  Created by 李政恩 on 06/12/2017.
//  Copyright © 2017 Beichi Techonology. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    var R = 240 as CGFloat
    var G = 240 as CGFloat
    var B = 240 as CGFloat
    
    @IBOutlet weak var TrumpPhoto: UIImageView!
    
    @IBOutlet weak var testUIView: UIView!
    
    @IBAction func sliderRed(_ sender: UISlider) {
        R = CGFloat(sender.value)
        testUIView.backgroundColor = UIColor(red: R / 255 , green: G / 255, blue: B / 255, alpha: 1)
    }
    
    @IBAction func sliderBlue(_ sender: UISlider) {
        G = CGFloat(sender.value)
        testUIView.backgroundColor = UIColor(red: R / 255 , green: G / 255, blue: B / 255, alpha: 1)
    }
    
    @IBAction func sliderGreen(_ sender: UISlider) {
        B = CGFloat(sender.value)
        testUIView.backgroundColor = UIColor(red: R / 255 , green: G / 255, blue: B / 255, alpha: 1)
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

