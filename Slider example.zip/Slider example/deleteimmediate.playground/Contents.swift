//: Playground - noun: a place where people can play

import UIKit

func tempature(number: Int) {
    let F = number * 9 / 5 + 32
    print(F)
}

tempature(number: 40)

func callNmae(Yes1: String, Yes2: String) {
    print(Yes1 + " and " + Yes2 + " is good. ")
}

callNmae(Yes1: "peter", Yes2: "John")

class TestClass {
    var parameter1 : Int! = 1
    var parameter2 : String! = "Yo"
}

var FetchOut = TestClass()
FetchOut.parameter2 = "rec"
print(FetchOut.parameter2)

